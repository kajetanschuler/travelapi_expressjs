
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'kajetanschuler',
  applicationName: 'travelution',
  appUid: 'X3HWzVYt2Dpldn4qkd',
  orgUid: 'MHtpjMgFdbhjgxwN9q',
  deploymentUid: '479afce8-0974-4a95-937f-5bc9c9030f10',
  serviceName: 'travelution',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'travelution-dev-app', timeout: 6 };

try {
  const userHandler = require('./app.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}