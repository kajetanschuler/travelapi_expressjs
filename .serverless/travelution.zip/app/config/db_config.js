module.exports = {
    HOST: "travelapidatabase.chuesgmxloap.eu-central-1.rds.amazonaws.com",
    USER: "TravelApiMaster",
    PASSWORD: "TravelApi2020",
    DB: "TravelApiDB",
  };