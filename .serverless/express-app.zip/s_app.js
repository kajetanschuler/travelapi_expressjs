
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'kajetanschuler',
  applicationName: 'my-first-app',
  appUid: 'bYDjHPKMsXT9LC4YF8',
  orgUid: 'MHtpjMgFdbhjgxwN9q',
  deploymentUid: '0143ed0f-0b95-441f-91e1-0f3d3c9176ee',
  serviceName: 'express-app',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'express-app-dev-app', timeout: 6 };

try {
  const userHandler = require('./app.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}