
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'discoverooapi',
  applicationName: 'discoveroo-api',
  appUid: 'BsZxfyZ4T7x2YdB1T9',
  orgUid: 'w2shmRc2FFVNbZ9LwM',
  deploymentUid: 'e12e6b2b-1923-427a-8116-bbb8184b7640',
  serviceName: 'discoveroo-api',
  shouldLogMeta: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'discoveroo-api-dev-app', timeout: 6 };

try {
  const userHandler = require('./app.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}